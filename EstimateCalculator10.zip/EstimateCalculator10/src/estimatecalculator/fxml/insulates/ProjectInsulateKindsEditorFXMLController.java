/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.fxml.insulates;

import static estimatecalculator.EstimateCalculator.currentInsulateThickID;
import static estimatecalculator.EstimateCalculator.currentInsulateTypeID;
import static estimatecalculator.classes.insulate.InsulateType.getInsulateTypeIDByName;
import static estimatecalculator.classes.insulate.InsulateType.getInsulateTypesNames;
import static estimatecalculator.classes.insulate.InsulatesThick.getInsulateThicksValues;
import estimatecalculator.classes.insulate.ProjectInsulateKind;
import static estimatecalculator.classes.insulate.ProjectInsulateKind.addProjectInsulateKind;
import static estimatecalculator.classes.insulate.ProjectInsulateKind.getProjectInsulateKinds;
import static estimatecalculator.classes.values.Thick.getThickIDByThickValue;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author I
 */
public class ProjectInsulateKindsEditorFXMLController implements Initializable {

    @FXML
    private TableView<ProjectInsulateKind> insulatesTableView;
    @FXML
    private TextField insulateKindNameField;
    @FXML
    private ComboBox insulateTypeComboBox;
    @FXML
    private ComboBox insulateThickComboBox;
    public static ObservableList<String> insulateTypesObservableList;
    public static ObservableList<ProjectInsulateKind> projectInsulateKindsObservableList;
    public static ObservableList<String> insulateNamesList = FXCollections.observableArrayList();
    public static ObservableList<String> insulateThickValuesList;
    private static SingleSelectionModel ssmInsulateNameComboBox;
    private static SingleSelectionModel ssmInsulateThickComboBox;

    @FXML
    protected void addInsulateKindFromEditor(ActionEvent event) throws SQLException {

        // Добавляем вид уровня
        addProjectInsulateKind(insulateKindNameField.getText(), currentInsulateTypeID, currentInsulateThickID);
        insulateKindNameField.setText("");
        initData();

    }

    @FXML
    protected void changeInsulateTypeName(TableColumn.CellEditEvent<ProjectInsulateKind, String> event) throws SQLException {
        ((ProjectInsulateKind) event.getTableView().getItems().get(event.getTablePosition().getRow())).setInsulate_type_name(event.getNewValue());
        currentInsulateTypeID = getInsulateTypeIDByName(event.getNewValue());
        System.out.println("currentInsulateTypeID = " + currentInsulateTypeID);
    }

    @FXML
    protected void changeInsulateThickValue(TableColumn.CellEditEvent<ProjectInsulateKind, String> event) {
        ((ProjectInsulateKind) event.getTableView().getItems().get(event.getTablePosition().getRow())).setInsulate_thick_value(event.getNewValue());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initData();
        try {
            setInsulateComboBox(0);
        } catch (SQLException ex) {
            Logger.getLogger(ProjectInsulateKindsEditorFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
        //     insulatesTableView.setEditable(true);
        onSelectInsulateFromTable();
        System.out.println("initialize");
    }

    private void initData() {
        // Загружаем в ObservableList данные из базы
        //   insulateTypesObservableList = FXCollections.observableArrayList(getInsulateTypes());// Загружаем все типы утеплителей 
        projectInsulateKindsObservableList = FXCollections.observableArrayList(getProjectInsulateKinds());// Загружаем виды утеплителей проекта
        //    projectInsulateKindsObservableList = FXCollections.observableArrayList(getProjectInsulateKinds());// Загружаем виды утеплителей проекта
        // Загружаем в TableView данные из ObservableList
        insulatesTableView.setItems(projectInsulateKindsObservableList);
        insulatesTableView.setEditable(true);
        //  insulateKindNameColumn.setEditable(true);
        insulatesTableView.setDisable(false);
        insulatesTableView.setManaged(true);
        insulatesTableView.setTableMenuButtonVisible(true);
    }

    // Наполняем комбобокс "Тип утеплителя"
    private void setInsulateComboBox(int sel) throws SQLException {
        insulateTypesObservableList = FXCollections.observableArrayList(getInsulateTypesNames());
        insulateTypeComboBox.setItems(insulateTypesObservableList);
        ssmInsulateNameComboBox = insulateTypeComboBox.getSelectionModel();
        ssmInsulateNameComboBox.select(sel);
        insulateTypeComboBox.setSelectionModel(ssmInsulateNameComboBox);
        if (insulateTypesObservableList.size() > 0) {
            currentInsulateTypeID = getInsulateTypeIDByName(insulateTypeComboBox.getSelectionModel().getSelectedItem().toString());
        }
        setInsulateThickComboBox(0);

    }

    private void onSelectInsulateFromTable() {
        insulatesTableView.getSelectionModel().selectedIndexProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                insulateKindNameField.setText(insulatesTableView.getSelectionModel().getSelectedItem().getName());
                
                try {
                    setInsulateComboBox(insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_type_id());
                    setInsulateThickComboBox(insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_thick_id());
                } catch (SQLException ex) {
                    Logger.getLogger(ProjectInsulateKindsEditorFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
//                ssmInsulateNameComboBox = insulateTypeComboBox.getSelectionModel();
//                ssmInsulateNameComboBox.select(insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_type_id());
//                insulateTypeComboBox.setSelectionModel(ssmInsulateNameComboBox);
                
//                ssmInsulateThickComboBox = insulateThickComboBox.getSelectionModel();
//                ssmInsulateThickComboBox.select(insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_thick_id());
//                insulateThickComboBox.setSelectionModel(ssmInsulateThickComboBox);
                
                System.out.println("insulatesTableView.selectionModelProperty().get().getFocusedIndex() = " + insulatesTableView.selectionModelProperty().get().getFocusedIndex());
                System.out.println("insulatesTableView.getSelectionModel().getSelectedIndex() = " + insulatesTableView.getSelectionModel().getSelectedIndex());
                System.out.println("insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_type_name().toString() = " + insulatesTableView.getSelectionModel().getSelectedItem().getInsulate_type_name().toString());

            }
        });
        System.out.println("insulatesTableView.selectionModelProperty().get().getFocusedIndex() = " + insulatesTableView.selectionModelProperty().get().getFocusedIndex());
    }

    // Определяем id выбранного типа утеплителя
    @FXML
    protected void getSelectedInsulateTypeID() throws SQLException {
        System.out.println("Определяем id выбранного типа утеплителя ");
        currentInsulateTypeID = getInsulateTypeIDByName(insulateTypeComboBox.getSelectionModel().getSelectedItem().toString());
        setInsulateThickComboBox(0);
    }

    // Наполняем комбобокс "Толщина утеплителя"
    private void setInsulateThickComboBox(int sel) throws SQLException {
        insulateThickValuesList = FXCollections.observableArrayList(getInsulateThicksValues(currentInsulateTypeID));
        insulateThickComboBox.setItems(insulateThickValuesList);
        ssmInsulateThickComboBox = insulateThickComboBox.getSelectionModel();
        ssmInsulateThickComboBox.select(sel);
        insulateThickComboBox.setSelectionModel(ssmInsulateThickComboBox);
        currentInsulateThickID = getThickIDByThickValue(insulateThickComboBox.getSelectionModel().getSelectedItem().toString());
        System.out.println("1 insulateThickComboBox.getSelectionModel().getSelectedItem().toString() = " + insulateThickComboBox.getSelectionModel().getSelectedItem().toString());
    }

    // Определяем id выбранной толщины утеплителя
    @FXML
    protected void getSelectedInsulateThickID() throws SQLException {
        if (insulateThickComboBox.getSelectionModel().getSelectedIndex() >= 0) { // Эта строчка отняла нереальное кол-во времени.
//            System.out.println("why?? ");
            try {
                currentInsulateThickID = getThickIDByThickValue(insulateThickComboBox.getSelectionModel().getSelectedItem().toString());
            } catch (SQLException ex) {
                Logger.getLogger(ProjectInsulateKindsEditorFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
