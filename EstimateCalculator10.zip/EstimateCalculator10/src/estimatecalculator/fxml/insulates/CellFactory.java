/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.fxml.insulates;

import static estimatecalculator.classes.insulate.InsulateType.getInsulateTypesNames;
import static estimatecalculator.fxml.insulates.ProjectInsulateKindsEditorFXMLController.insulateNamesList;
import java.text.Format;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.text.TextAlignment;
import javafx.util.Callback;
import javafx.util.StringConverter;


/**
 *
 * @author I
 * @param <S>
 * @param <T>
 */
public class CellFactory<S, T> implements Callback<TableColumn<S, T>, ComboBoxTableCell<S, T>> {


    private TextAlignment alignment;
    private Format format;
    private ObservableList<String> insulateTypesNamesList = FXCollections.observableArrayList(getInsulateTypesNames());

   

    public TextAlignment getAlignment() {
        return alignment;
    }

    public void setAlignment(TextAlignment alignment) {
        this.alignment = alignment;
    }

    public Format getFormat() {
        return format;
    }

    public void setFormat(Format format) {
        this.format = format;
    }
    


    @Override
    @SuppressWarnings("unchecked")
    public ComboBoxTableCell<S, T> call(TableColumn<S, T> p) {
        ComboBoxTableCell<S, T> cell = new ComboBoxTableCell(insulateTypesNamesList) {
            @Override
            public void updateItem(Object item, boolean empty) {
                if (item == getItem()) {
                    return;
                }
                super.updateItem((T) item, empty);
                if (item == null) {
                    super.setText(null);
                    super.setGraphic(null);
                } else if (format != null) {
                    super.setText(format.format(item));
                } else if (item instanceof Node) {
                    super.setText(null);
                    super.setGraphic((Node) item);
                } else {
                    super.setText(item.toString());
                    super.setGraphic(null);
                }
            }

        };
        cell.setConverter(new StringConverter<T>() {
            @Override
            public String toString(T object) {
                return object.toString();
            }
            @Override
            public T fromString(String string) {
                return (T) string;
            }
        });
        cell.setTextAlignment(alignment);
        switch (alignment) {
            case CENTER:
                cell.setAlignment(Pos.CENTER);
                break;
            case RIGHT:
                cell.setAlignment(Pos.CENTER_RIGHT);
                break;
            default:
                cell.setAlignment(Pos.CENTER_LEFT);
                break;
        }
        return cell;
    }
    
}
