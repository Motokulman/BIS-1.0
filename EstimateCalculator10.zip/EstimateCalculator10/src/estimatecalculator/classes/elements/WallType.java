/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.elements;

import javafx.scene.paint.Color;

/**
 *
 * @author I
 */
public class WallType {

    private String type;
    private Color color;
    private double thick;

    public WallType(String type, Color color, double thick) {
        this.type = type;
        this.color = color;
        this.thick = thick;
    }

    public String getType() {
        return type;
    }

    public Color getColor() {
        return color;
    }

    public double getThick() {
        return thick;
    }

//    public void setTypeColorThick(String type, Color color, double thick) {
//        this.type = type;
//        this.color = color;
//        this.thick = thick;
//    }
}
