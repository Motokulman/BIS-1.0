/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.elements;

//Класс главной несущей стены



public class Element {
    private int z0;
    private int z1;
 //   private ElementTypeEnum type;
    
}
