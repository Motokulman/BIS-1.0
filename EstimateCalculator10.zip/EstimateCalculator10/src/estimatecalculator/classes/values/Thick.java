/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.values;

import static estimatecalculator.EstimateCalculator.main_dB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author I
 */
public class Thick {

    private int id;
    private double thick;

    public Thick(int id, double thick) {
        this.id = id;
        this.thick = thick;
    }

    // Добавление Thick
    public static void addThick(int insulate_type_id, double thick) {
        try (PreparedStatement statement = main_dB.getMainDBConnection().prepareStatement(
                "INSERT INTO Thicks(`thick`) "
                + "VALUES(?)")) {
            statement.setObject(1, thick);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Получение Thicks
    public static List<Thick> getThicks() {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            List<Thick> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT ID, thick FROM Thicks");
            while (resultSet.next()) {
                products.add(new Thick(
                        resultSet.getInt("ID"),
                        resultSet.getDouble("thick")));
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
    
    
    // Получение значеня толщины по заданному id 
    public static String getThickByID(int id) throws SQLException {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT thick FROM Thicks WHERE id = " + id);
            String i = resultSet.getString("thick");
            return i;
        }
    }
    
    
    // Получение id толщины  по его ЧП толщине
    public static int getThickIDByThickValue(String thick) throws SQLException {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT ID FROM Thicks WHERE thick LIKE  '" + thick + "'");
            int i = resultSet.getInt("ID");
            return i;
        }
    }

    public int getId() {
        return id;
    }

    public double getThick() {
        return thick;
    }

}
