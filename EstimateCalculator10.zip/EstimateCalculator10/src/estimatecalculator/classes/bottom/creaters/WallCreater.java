/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.bottom.creaters;

/**
 *
 * @author I
 */
public class WallCreater {
    private static int temp_x0_id = -1;
}
