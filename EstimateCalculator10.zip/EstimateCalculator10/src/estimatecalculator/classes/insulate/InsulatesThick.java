/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.insulate;

import static estimatecalculator.EstimateCalculator.main_dB;
import static estimatecalculator.classes.values.Thick.getThickByID;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author I
 */
public class InsulatesThick {

    private int id;
    private int insulate_id;
    private int thick_id;

    public InsulatesThick(int id, int insulate_id, int thick_id) {
        this.id = id;
        this.insulate_id = insulate_id;
        this.thick_id = thick_id;
    }

    public static void addInsulatesThick(int insulate_id, int thick_id) {
        try (PreparedStatement statement = main_dB.getMainDBConnection().prepareStatement(
                "INSERT INTO InsulatesThicks(`insulate_id`, `thick_id`) "
                + "VALUES(?, ?)")) {
            statement.setObject(1, insulate_id);
            statement.setObject(2, thick_id);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Получение InsulateThicks
    public static List<InsulatesThick> getInsulateThicks() {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            List<InsulatesThick> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT ID, insulate_id, thick_id FROM Thicks");
            while (resultSet.next()) {
                products.add(new InsulatesThick(
                        resultSet.getInt("ID"),
                        resultSet.getInt("insulate_id"),
                        resultSet.getInt("thick_id")));
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // Получение значений толщин для утеплителя с заданным id
    public static List<String> getInsulateThicksValues(int id) {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            List<String> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT thick_id FROM InsulatesThicks WHERE insulate_id = " + id);
            while (resultSet.next()) {
                products.add(getThickByID(resultSet.getInt("thick_id")));
           }
           
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public int getId() {
        return id;
    }

    public int getInsulate_id() {
        return insulate_id;
    }

    public int getThick_id() {
        return thick_id;
    }

}
