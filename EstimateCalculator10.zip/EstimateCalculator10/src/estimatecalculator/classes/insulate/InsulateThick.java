/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.insulate;

import static estimatecalculator.EstimateCalculator.main_dB;
import static estimatecalculator.EstimateCalculator.project_dB;
import estimatecalculator.classes.elements.Level;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author I
 */
public class InsulateThick {

    private int id;
    private int insulate_type_id;
    private double thick;

    public InsulateThick(int id, int insulate_type_id, double thick) {
        this.id = id;
        this.insulate_type_id = insulate_type_id;
        this.thick = thick;
    }

    // Добавление InsulateThick
    public static void addInsulateThick(int insulate_type_id, double thick) {
        try (PreparedStatement statement = main_dB.getMainDBConnection().prepareStatement(
                "INSERT INTO InsulateThicks(`insulate_type_id`, `thick`) "
                + "VALUES(?, ?)")) {
            statement.setObject(1, insulate_type_id);
            statement.setObject(2, thick);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Получение InsulateThicks
    public static List<InsulateThick> getInsulateThicks() {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            List<InsulateThick> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT ID, insulate_type_id, thick FROM InsulateThicks");
            while (resultSet.next()) {
                products.add(new InsulateThick(
                        resultSet.getInt("ID"),
                        resultSet.getInt("insulate_type_id"),
                        resultSet.getDouble("thick")));
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
    
    
    // Получение толщин для заданного утеплителя
    public static List<Double> getInsulateThicksByInsulateID(int id) throws SQLException {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            List<Double> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT ID FROM InsulateThicks WHERE insulate_type_id LIKE  '" + id + "'");
            while (resultSet.next()) {
                products.add(resultSet.getDouble("thick"));
            }
            return products;
        }
    }
    
    
    // Получение id толщины утеплителя по его ЧП имени
    public static int getInsulateThickIDByName(String name) throws SQLException {
        try (Statement statement = main_dB.getMainDBConnection().createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT ID FROM InsulateThicks WHERE name LIKE  '" + name + "'");
            int i = resultSet.getInt("ID");
            return i;
        }
    }

    public int getId() {
        return id;
    }

    public int getInsulate_id() {
        return insulate_type_id;
    }

    public double getThick() {
        return thick;
    }

}
