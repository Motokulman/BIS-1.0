/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estimatecalculator.classes.insulate;

import static estimatecalculator.EstimateCalculator.project_dB;
import static estimatecalculator.classes.insulate.InsulateType.getInsulateTypeNameByID;
import static estimatecalculator.classes.values.Thick.getThickByID;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author I
 */
public class ProjectInsulateKind {

    private int id;
    private String name;
    private Integer insulate_type_id; // тип утеплителя, хрs или минвата и т.д., без конкретики. Может не быть утеплителя!
    private Integer insulate_thick_id; // толщина утеплителя. Может не быть утеплителя!
    private SimpleStringProperty insulate_type_name;// = new SimpleStringProperty("");
    private SimpleStringProperty insulate_thick_value;

    private SimpleStringProperty temp_insulate_type_name;
    private SimpleStringProperty temp_insulate_thick_value;

    public ProjectInsulateKind(int id, String name, int insulate_type_id, int insulate_thick_id) throws SQLException {
        this.temp_insulate_type_name = new SimpleStringProperty(getInsulateTypeNameByID(insulate_type_id));
        this.temp_insulate_thick_value = new SimpleStringProperty(getThickByID(insulate_thick_id));
        this.id = id;
        this.name = name;
        this.insulate_type_id = insulate_type_id;
        this.insulate_thick_id = insulate_thick_id;
        this.insulate_type_name = temp_insulate_type_name;
        this.insulate_thick_value = temp_insulate_thick_value;
     //   System.out.println("this.insulate_thick_value = " + temp_insulate_thick_value.toString());
    }
    // Добавление вида утеплителя

    public static void addProjectInsulateKind(String name, int insulate_type_id, int insulate_thick_id) {
        try (PreparedStatement statement = project_dB.getConnectionProjectDB().prepareStatement(
                "INSERT INTO ProjectInsulateKinds(`name`, `insulate_type_id`, `insulate_thick_id`) "
                + "VALUES(?, ?, ?)")) {
            statement.setObject(1, name);
            statement.setObject(2, insulate_type_id);
            statement.setObject(3, insulate_thick_id);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Получение Типов утеплителей
    public static List<ProjectInsulateKind> getProjectInsulateKinds() {
        try (Statement statement = project_dB.getConnectionProjectDB().createStatement()) {
            List<ProjectInsulateKind> products = new ArrayList<>();
            ResultSet resultSet = statement.executeQuery("SELECT ID, name, insulate_type_id, insulate_thick_id FROM ProjectInsulateKinds");
            while (resultSet.next()) {
                products.add(new ProjectInsulateKind(
                        resultSet.getInt("ID"),
                        resultSet.getString("name"),
                        resultSet.getInt("insulate_type_id"),
                        resultSet.getInt("insulate_thick_id")));
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public void setInsulate_type_name(String i_t_n) {
        insulate_type_name.set(i_t_n);
    }

    public void setInsulate_thick_value(String i_thick_n) {
        insulate_thick_value.set(i_thick_n);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getInsulate_type_id() {
        return insulate_type_id;
    }

    public Integer getInsulate_thick_id() {
        return insulate_thick_id;
    }

    public String getInsulate_type_name() {
        return insulate_type_name.get();
    }

    public String getInsulate_thick_value() {
        return insulate_thick_value.get();
    }
    public SimpleStringProperty getInsulate_thick_valueSSP() {
        return insulate_thick_value;
    }
 
    public void setInsulate_type_id(Integer insulate_type_id) {
        this.insulate_type_id = insulate_type_id;
    }

}
